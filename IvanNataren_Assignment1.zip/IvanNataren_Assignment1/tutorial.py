training = [
  [65, 78, 89, 79, 78, 69],   # ANYONE
  [85, 80, 82, 79, 65, 82],   # UPROAR
  [89, 69, 76, 76, 79, 87],   # YELLOW
  [66, 196, 82, 71, 69, 84],  # BÄRGET
  [90, 85, 82, 85, 70, 69],   # ZURUFE
  [87, 220, 83, 84, 69, 77]   # WÜSTEM
]

target = [
    0, # English  (ANYONE)
    0, # English  (UPROAR)
    0, # English  (YELLOW)
    1, # German   (BÄRGET)
    1, # German   (ZURUFE)
    1  # German   (WÜSTEM)
]

from sklearn.neighbors import KNeighborsClassifier
from sklearn import svm
from sklearn.neural_network import MLPClassifier

knn_model = KNeighborsClassifier()
svm_model = svm.SVC()
mlp_nn = MLPClassifier()

knn_model.fit(training, target)
svm_model.fit(training, target)
mlp_nn.fit(training, target)

# Predicting “ANYONE”
print(knn_model.predict([[65, 78, 89, 79, 78, 69]])) # Output: 0 (English)
print(svm_model.predict([[65, 78, 89, 79, 78, 69]])) # Output: 0 (English)
print(mlp_nn.predict([[65, 78, 89, 79, 78, 69]])) # Output: 0 (English)

# Predicting “BÄRGET”
print(knn_model.predict([[66, 196, 82, 71, 69, 84]])) # Output: 1 (German)
print(svm_model.predict([[66, 196, 82, 71, 69, 84]])) # Output: 1 (German)
print(mlp_nn.predict([[66, 196, 82, 71, 69, 84]])) # Output: 1 (German)

import numpy as np
import matplotlib.pyplot as plt

# Label text for each graph
labels = ("KNN", "SVM", "MLP")

# Numbers that you want the bars to represent
value = [81, 90, 71]

# Title of the plot
plt.title("Model Accuracy")

# Label for the x values of the bar graph
plt.xlabel("Accuracy")

# Drawing the bar graph
y_pos = np.arange(len(labels))
plt.barh(y_pos, value, align="center", alpha=0.5)
plt.yticks(y_pos, labels)

# Display the graph
plt.show()

