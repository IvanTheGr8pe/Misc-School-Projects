import random

def createList( input):
    input_list = [line.rstrip() for line in input.readlines()]
    input.close()
    ilist = []
    for x in input_list:
        if len(x) == 5:
            ilist.append(x)
    return ilist
def create_training_target( word_list, num):
    training_dataset = []
    target_dataset = []

    for line in word_list:

        training_dataset.append([ord(char) for char in line])
        target_dataset.append(num)
    return (training_dataset,target_dataset)

def findValue (input1,input2,input3,num1, num2, num3):
    a = 0
    b = 0
    c = 0

    for i in input1:
        if i == num1:
            a+=1

    for i in input2:
        if i == num2:
            b+=1
    for i in input3:
        if i == num3:
            c+=1
    return  ((a+b+c)/(len(input1)+len(input2)+len(input3)))*100
english_file = open("english.txt")
english_list = createList(english_file)
e_training_dataset , e_target_dataset = create_training_target( english_list, 0)


german_file = open("german.txt")
german_list = createList(german_file)
g_training_dataset , g_target_dataset = create_training_target( german_list, 1)


czech_file = open("czech.txt")
czech_list = createList(czech_file)
c_training_dataset , c_target_dataset = create_training_target( czech_list, 2)


random.shuffle(e_training_dataset)
random.shuffle(g_training_dataset)
random.shuffle(c_training_dataset)

split1 = int(len(e_training_dataset)*0.8)
split1_english = e_training_dataset[:split1]
split2_english = e_training_dataset[split1:]

split2  = int(len(g_training_dataset)*0.8)
split1_german = g_training_dataset[:split2]
split2_german = g_training_dataset[split2:]

split3 = int(len(c_training_dataset)*0.8)
split1_czech = c_training_dataset[:split3]
split2_czech = c_training_dataset[split3:]

from sklearn.neighbors import KNeighborsClassifier
from sklearn import svm
from sklearn.neural_network import MLPClassifier

knn_model = KNeighborsClassifier()
svm_model = svm.SVC()
mlp_nn = MLPClassifier()

training = split1_english + split1_czech + split1_german
target = e_target_dataset[:split1]+ c_target_dataset[:split3] + g_target_dataset[:split2]


knn_model.fit(training, target)
svm_model.fit(training, target)
mlp_nn.fit(training, target)

value1 = findValue(knn_model.predict((split2_english)),knn_model.predict((split2_german)),knn_model.predict((split2_czech)),0,1,2)
print(value1)

value2 = findValue(svm_model.predict((split2_english)),svm_model.predict((split2_german)),svm_model.predict((split2_czech)),0,1,2)
print(value2)

value3 = findValue(mlp_nn.predict((split2_english)),mlp_nn.predict((split2_german)),mlp_nn.predict((split2_czech)),0,1,2)
print(value3)


"""print(knn_model.predict((split2_english)))
print(svm_model.predict((split2_english)))
print(mlp_nn.predict((split2_english)))


print(knn_model.predict((split2_german))) # Output: 1 (German)
print(svm_model.predict((split2_german))) # Output: 1 (German)
print(mlp_nn.predict((split2_german))) # Output: 1 (German)


print(knn_model.predict((split2_czech))) # Output: 2 (czech)
print(svm_model.predict((split2_czech))) # Output: 2 (czech)
print(mlp_nn.predict((split2_czech))) # Output: 2 (czech)"""




import numpy as np
import matplotlib.pyplot as plt

# Label text for each graph
labels = ("KNN", "SVM", "MLP")

# Numbers that you want the bars to represent


value = [value1, value2, value3]

# Title of the plot
plt.title("Model Accuracy")

# Label for the x values of the bar graph
plt.xlabel("Accuracy")

# Drawing the bar graph
y_pos = np.arange(len(labels))
plt.barh(y_pos, value, align="center", alpha=0.5)
plt.yticks(y_pos, labels)

# Display the graph
plt.show()


